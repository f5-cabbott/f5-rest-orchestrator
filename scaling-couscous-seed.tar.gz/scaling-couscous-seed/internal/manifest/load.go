// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package manifest

import (
	"context"
	"fmt"
)

// Loader walks a manifest directory tree and returns a resolved Set.
//
// Implementations are expected to:
//   - parse every YAML document in the tree (multi-doc files allowed),
//   - validate each document against the JSON Schema for its kind,
//   - reject any literal secret material (only secret:// URIs and
//     CredentialsRef values are permitted),
//   - cross-reference ManagedCertificate.spec.deviceRef against device
//     metadata.name and partition membership,
//   - return a single Set per GatewayConfig (one environment).
type Loader interface {
	Load(ctx context.Context, root string) (*Set, error)
}

// ValidationError is the structured error returned by Loader.Load when
// validation fails. It carries one entry per offending document.
type ValidationError struct {
	Issues []Issue
}

type Issue struct {
	Path    string // file path relative to the manifest root
	Pointer string // JSON Pointer into the document
	Kind    string // GatewayConfig | BigIPDevice | ManagedCertificate | <unknown>
	Message string
}

func (e *ValidationError) Error() string {
	return fmt.Sprintf("manifest validation failed: %d issue(s)", len(e.Issues))
}
