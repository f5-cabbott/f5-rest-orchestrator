// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newRotateEABCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "rotate-eab",
		Short: "Mint new EAB credentials, migrate ACME accounts, then revoke the old EAB",
		Long: `Per the configured EAB scope (per-device / per-partition / per-environment),
mints new (kid, hmacKey) pairs at the gateway, writes them to the secret
backend, reconfigures the BIG-IP native ACME client to bind a new account
under the new EAB, verifies a successful order, then revokes the previous
EAB. Idempotent and resumable.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("rotate-eab")
		},
	}
	cmd.Flags().StringSlice("scope", nil, "Limit rotation to specific scopes (e.g. device=bigip-dc1-01,partition=tenant-a)")
	cmd.Flags().Bool("yes", false, "Skip confirmation")
	return cmd
}
