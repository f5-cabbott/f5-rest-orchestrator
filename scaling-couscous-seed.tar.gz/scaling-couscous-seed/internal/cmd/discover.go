// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newDiscoverCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "discover",
		Short: "Inspect current state of gateway EABs and BIG-IP ACME config; emit observed-state report",
		Long: `Read-only. Lists existing EABs at the AnyCA Gateway admin API and
queries each BigIPDevice via iControl REST for: TMOS version, ACME provider
configuration, configured ACME accounts, installed certs, and SSL profile
bindings. Output is a structured snapshot used by 'plan'.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("discover")
		},
	}
	cmd.Flags().String("output", "yaml", "yaml|json")
	return cmd
}
