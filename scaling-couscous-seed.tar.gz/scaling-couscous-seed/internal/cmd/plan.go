// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newPlanCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "plan",
		Short: "Diff desired manifests against discovered state; emit a change set",
		Long: `Composes 'validate' + 'discover' and produces a human-readable diff
plus a machine-readable plan file (when --out is set) consumable by 'apply'.
Exit codes: 0 = no changes; 2 = changes pending; non-zero otherwise.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("plan")
		},
	}
	cmd.Flags().String("out", "", "Write the machine-readable plan to this path")
	cmd.Flags().Bool("detailed-exitcode", false, "Use exit code 2 to signal pending changes")
	return cmd
}
