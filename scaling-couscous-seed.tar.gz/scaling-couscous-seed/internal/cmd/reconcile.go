// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"time"

	"github.com/spf13/cobra"
)

func newReconcileCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "reconcile",
		Short: "Read-only drift / expiry / orphan detection; emits metrics and alerts",
		Long: `Runs on a schedule (CI cron, k8s CronJob, systemd timer). Diffs
each BIG-IP's installed certs against state and manifests; classifies findings
as drift, orphan-on-device, missing-on-device, near-expiry, or
recent-renewal-failure. Emits Prometheus metrics on the port given by
--metrics-addr and exits non-zero if any class triggers an alert threshold.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("reconcile")
		},
	}
	cmd.Flags().String("metrics-addr", ":9090", "Listen address for /metrics; empty disables")
	cmd.Flags().Duration("expiry-warn", 14*24*time.Hour, "Warn when a cert's notAfter is within this duration")
	cmd.Flags().Bool("once", true, "Run a single reconcile pass and exit (set false to loop)")
	return cmd
}
