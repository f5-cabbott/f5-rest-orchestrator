// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newValidateCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "validate",
		Short: "Schema-validate manifests; resolve secret references without reading values",
		Long: `Walks the manifest directory, parses YAML, validates each document
against its kind's JSON Schema, and confirms every secret:// reference exists
in the configured backend (without fetching the secret value). Exits non-zero
on any validation error.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("validate")
		},
	}
}
