// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newRevokeCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "revoke <managedcertificate-name>",
		Short: "Revoke an issued certificate via ACME revokeCert and remove from BIG-IP",
		Long: `Submits an ACME revokeCert request through the gateway, then unbinds
the cert from any SSL profiles and removes it from the BIG-IP filestore.
Reason codes follow RFC 5280.`,
		Args: cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("revoke")
		},
	}
	cmd.Flags().Int("reason", 0, "RFC 5280 revocation reason code")
	cmd.Flags().Bool("yes", false, "Skip confirmation")
	return cmd
}
