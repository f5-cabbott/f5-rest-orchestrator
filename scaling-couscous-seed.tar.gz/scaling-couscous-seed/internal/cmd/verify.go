// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newVerifyCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "verify",
		Short: "Post-apply checks: certs installed, chains valid, profiles point at the right cert",
		Long: `For each ManagedCertificate in scope: confirm the cert exists on the
target BIG-IP, that notAfter is in the future and beyond the renewal window,
that the chain validates against the trusted CA bundle, and that the
configured client/serverSSL profiles reference the issued cert and key.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return errNotImplemented("verify")
		},
	}
}
