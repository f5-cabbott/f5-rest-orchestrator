// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

type globalOpts struct {
	manifestDir string
	stateURI    string
	logLevel    string
	logFormat   string
}

var opts globalOpts

func NewRoot() *cobra.Command {
	root := &cobra.Command{
		Use:           "f5acmectl",
		Short:         "Declaratively manage BIG-IP ACMEv2 cert lifecycle against a Keyfactor AnyCA Gateway",
		SilenceUsage:  true,
		SilenceErrors: true,
	}

	root.PersistentFlags().StringVarP(&opts.manifestDir, "manifests", "m", "./environments", "Path to manifest directory tree")
	root.PersistentFlags().StringVar(&opts.stateURI, "state", "", "State backend URI (s3://, gs://, az://, file://)")
	root.PersistentFlags().StringVar(&opts.logLevel, "log-level", "info", "trace|debug|info|warn|error")
	root.PersistentFlags().StringVar(&opts.logFormat, "log-format", "json", "json|text")

	root.AddCommand(
		newValidateCmd(),
		newDiscoverCmd(),
		newPlanCmd(),
		newApplyCmd(),
		newVerifyCmd(),
		newReconcileCmd(),
		newRevokeCmd(),
		newRotateEABCmd(),
		newStateCmd(),
		newVersionCmd(),
	)

	return root
}
