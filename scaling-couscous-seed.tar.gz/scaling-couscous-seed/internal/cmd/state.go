// Copyright 2026 F5-cabbott contributors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cmd

import (
	"github.com/spf13/cobra"
)

func newStateCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "state",
		Short: "Inspect or manipulate the f5acmectl state backend",
	}
	cmd.AddCommand(
		&cobra.Command{
			Use:   "show",
			Short: "Print the current state snapshot",
			RunE:  func(cmd *cobra.Command, args []string) error { return errNotImplemented("state show") },
		},
		&cobra.Command{
			Use:   "list",
			Short: "List versioned state snapshots",
			RunE:  func(cmd *cobra.Command, args []string) error { return errNotImplemented("state list") },
		},
		&cobra.Command{
			Use:   "lock",
			Short: "Acquire the state lock (advisory; for emergency holds)",
			RunE:  func(cmd *cobra.Command, args []string) error { return errNotImplemented("state lock") },
		},
		&cobra.Command{
			Use:   "unlock",
			Short: "Force-release a stuck state lock",
			RunE:  func(cmd *cobra.Command, args []string) error { return errNotImplemented("state unlock") },
		},
	)
	return cmd
}
