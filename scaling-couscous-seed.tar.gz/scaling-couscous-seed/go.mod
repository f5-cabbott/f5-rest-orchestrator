module github.com/f5-cabbott/scaling-couscous

go 1.22

require (
	github.com/spf13/cobra v1.8.0
	gopkg.in/yaml.v3 v3.0.1
)
