# External Account Binding (EAB)

EAB is the ACMEv2 mechanism (RFC 8555 §7.3.4) that lets a private or
enterprise ACME server require pre-authorization before creating an
account.

## Why we use it

Public ACME (Let's Encrypt) is open — anyone can call `newAccount` and
order certs as long as they pass a domain-control challenge. For an
internal CA fronted by Keyfactor, that model breaks: we need to tie ACME
orders back to a known requester, enforce per-requester policy
(template, validity, allowed identifiers), and have an audit trail.

EAB is the bridge. The gateway refuses `newAccount` unless the request
is signed by a key the admin pre-issued.

## How it works

1. **Admin provisions an EAB credential** in the AnyCA Gateway admin
   API (`f5acmectl` does this — never via the UI):
   - `kid` — public key identifier (an opaque string, like an account
     name).
   - `hmacKey` — base64url-encoded HMAC secret.
2. **Admin attaches policy** to that `kid`: which Keyfactor cert
   template to use, allowed identifiers/SANs, key types, validity.
3. **Client (BIG-IP)** is configured with `(directoryURL, kid, hmacKey)`.
4. **First ACME run:** the client's `newAccount` request includes an
   `externalAccountBinding` JWS signed with `hmacKey`. The gateway
   verifies the HMAC, looks up the `kid`, and creates the ACME account
   bound to that policy.
5. **Subsequent orders** authenticate via the ACME account key (created
   in step 4); the EAB material isn't sent again unless the account is
   re-created.

## Scoping decision

The choice of *what a `kid` represents* is a real design decision. This
project's default is **per-partition**, but the schema lets you pick.

| Scope | Pros | Cons |
|---|---|---|
| **per-device** | Tightest blast radius; revoke one device without touching others; per-device audit | More credentials to provision and rotate |
| **per-partition** *(default)* | Matches BIG-IP's existing tenancy model; fewer creds; per-tenant audit | A compromised partition admin can mint anything that partition is authorized for |
| **per-environment** (prod / stage / dev) | Easiest to operate | Coarse audit; revoking it knocks out everything in that env |

There is no single right answer — track how trust is already segmented
on the F5 side. If your partitions already map to tenants/business
units, per-partition is usually the sweet spot.

## Operational rules

- **Treat `hmacKey` as a secret.** It's bearer-equivalent until the ACME
  account is created. Store in the configured secret backend; never
  commit, never log, never email.
- **Account key ≠ EAB key.** After `newAccount`, the per-ACME-account
  keypair the BIG-IP generates authenticates ongoing orders. Losing the
  account key means re-binding via EAB; losing the EAB without the
  account key means existing accounts keep working but no new ones can
  be created.
- **Rotation.** `f5acmectl rotate-eab` mints new credentials, migrates
  the ACME accounts on the BIG-IP to bind under the new EAB, verifies
  a successful order, then revokes the old EAB. Idempotent and
  resumable.
- **Logging.** The `kid` is fine to log and is the audit handle. Never
  log the `hmacKey` or any `Authorization` header.
- **Compromise response.** If an EAB is suspected compromised: revoke
  the EAB at the gateway (other accounts under the same scope keep
  functioning if their account keys are intact); rotate to a fresh EAB
  via `f5acmectl rotate-eab`; review issuance logs at the gateway for
  unauthorized orders within the validity window.

## Configuration shape

In a `GatewayConfig`:

```yaml
spec:
  eab:
    scope: per-partition          # per-device | per-partition | per-environment
    rotationDays: 365
    secretBackend: vault
    secretPathTemplate: "kv/f5acme/{env}/{device}/{partition}/eab"
```

Under that template, `f5acmectl` writes one secret per scope unit, each
containing `kid` and `hmacKey` keys. The BIG-IP API account at runtime
reads its own EAB by following the same template.
