# Operations runbook

Procedures for the on-call engineer. Keep updated as the tool matures.

## Alerts

### `f5acme_renewal_failure` — a cert failed to renew

1. Identify the cert: alert payload includes `device`, `partition`,
   `cert.name`, `identifiers`, `last_attempt_at`, and `error`.
2. Check time-to-expiry. If `notAfter` is more than 14 days out, you
   have time — investigate before forcing a rotation.
3. Common causes:
   - **Challenge failure (DNS-01):** DNS provider creds expired or
     rate-limited. Check the BIG-IP ACME client log; rotate provider
     creds; re-trigger.
   - **Challenge failure (HTTP-01):** ACL/firewall rule changed and the
     gateway can no longer reach :80. Restore reachability or switch
     the cert to DNS-01.
   - **Gateway unreachable:** check gateway health endpoint; fall back
     to gateway HA peer.
   - **Policy mismatch:** identifier added to the manifest isn't on the
     EAB's allowed-identifier list. Update gateway policy mapping.
4. Force a renewal attempt:
   - On the BIG-IP, trigger the ACME client's renew action for the
     specific managed cert (TMSH command — confirm exact syntax against
     17.5 docs).
   - Or run `f5acmectl apply` if the manifest changed.
5. Re-arm: confirm next renewal succeeds in the reconciler within 2
   reconcile cycles.

### `f5acme_cert_expiring` — cert within 14 days, no successful renewal

Treat as P2. Same diagnosis path as renewal failure, but tighter clock.
If the cert is within 48 hours and renewal is still failing,
**emergency rotation**:

1. Issue a manual cert through Keyfactor (out-of-band, not via this
   tool).
2. Install via iControl REST and bind to the affected SSL profiles.
3. Open an incident issue against this repo with the renewal-failure
   detail; do not unwind the manual cert until the ACME path is
   re-confirmed working.

### `f5acme_drift` — observed state diverges from desired

1. Run `f5acmectl discover -m <env>` and compare to the manifests.
2. Common causes:
   - Operator made an out-of-band change via the BIG-IP UI.
   - Another tool (legacy orchestrator during migration; AS3
     declaration) re-applied an old config.
   - Manual cert install bypassed `f5acmectl`.
3. Decide: roll the device forward to match manifests
   (`f5acmectl apply --plan-file <plan>`), or update the manifests to
   match reality (commit + PR + apply via CI).
4. Do **not** run `apply` directly to "fix" drift without going through
   the manifest repo — bypassing GitOps defeats the audit trail.

### `f5acme_orphan_eab` — EAB exists at gateway but no manifest references it

1. Check git history for recent device or partition removals.
2. If intentional, run `f5acmectl rotate-eab --scope <kid>` with the
   revoke flag to clean up.
3. If unintentional, restore the manifest from history.

## Procedures

### EAB compromise response

1. **Revoke** the suspect EAB at the gateway:
   `f5acmectl rotate-eab --scope <kid> --yes`. This mints a replacement
   EAB, migrates ACME accounts under it, then revokes the old one.
2. Pull the gateway's issuance log for the validity window of the
   compromised credential. Look for orders not corresponding to a
   known `ManagedCertificate`.
3. For any unauthorized issuance: revoke via
   `f5acmectl revoke <cert-name> --reason 1` (key compromise per
   RFC 5280).
4. File a security incident; notify the PKI team.

### Gateway upgrade (24.2 → 24.x)

1. Schedule maintenance window. Existing ACME accounts continue to
   function across gateway upgrades; new orders pause for the window.
2. Snapshot gateway config + EAB list.
3. Apply upgrade per Keyfactor procedure.
4. Smoke-test: `f5acmectl discover -m lab` against the upgraded
   gateway; confirm EAB list and policy mappings are intact.
5. Verify in lab one renewal cycle on at least one cert before promoting
   stage and prod.

### Stuck state lock

If a previous `apply` crashed and left the state backend locked:

1. `f5acmectl state list` — confirm the lock holder and TTL.
2. Wait for TTL expiry if possible.
3. If urgent: `f5acmectl state unlock --force` (audit-logged).

### Recovering from a corrupted snapshot

State backends are versioned. Roll back to a prior snapshot:

1. `f5acmectl state list --limit 10` — identify a known-good snapshot
   ID.
2. `f5acmectl state show <id>` — confirm contents.
3. `f5acmectl apply --revert <id>` — applies that snapshot as the new
   desired state.

This does not revoke certs already issued under the discarded snapshot;
let them expire naturally or invoke `f5acmectl revoke` per cert.

## Escalation

| Symptom | First responder | Escalate to |
|---|---|---|
| Single cert renewal failure | On-call platform engineer | PKI team if gateway-side |
| Multiple cert renewal failures across one BIG-IP | Platform engineer | Network engineering |
| Multiple cert renewal failures across multiple BIG-IPs | Platform engineer | PKI team + Keyfactor support |
| Suspected EAB compromise | On-call security | PKI team + incident commander |
| Gateway down | PKI team | Keyfactor support |
| BIG-IP API auth failure on every request | Platform engineer | Identity team (service account) |
