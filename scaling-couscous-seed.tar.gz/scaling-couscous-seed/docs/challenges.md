# Challenge type selection

ACMEv2 specifies three domain-control challenge types. BIG-IP TMOS
17.5+ native ACME client supports all three. This project lets you pick
per certificate.

## Quick chooser

| Challenge | Use for | Avoid for | Notes |
|---|---|---|---|
| **HTTP-01** | Public-facing HTTPS VIPs that already accept :80 (or can briefly), single-name certs | Wildcards (not allowed); VIPs with no :80 listener; internal-only VIPs the gateway can't reach | Cheapest to operate. Needs the gateway → VIP path open on :80. |
| **DNS-01** | Wildcards; internal-only VIPs; VIPs behind WAF/auth; anything where the gateway can't reach the listener | Environments where DNS API access is restricted | Most flexible. Requires DNS provider creds on the BIG-IP. Slowest due to DNS propagation. |
| **TLS-ALPN-01** | VIPs that have :443 open but can't accept :80 and you don't want to touch DNS | VIPs fronted by a TLS-terminating device that doesn't speak ALPN | Niche. Same single-name limitation as HTTP-01 (no wildcards). |

## Defaults

Set in `GatewayConfig.spec.defaults.challenge`:

- **`dns-01`** as the default if you have a DNS provider integration
  handy — works for everything, including wildcards, including internal
  VIPs.
- **`http-01`** as the default if most VIPs are public-facing web and
  you want to avoid handing DNS API credentials to BIG-IPs.

Override per cert via `ManagedCertificate.spec.challenge`.

## DNS-01 specifics

- The BIG-IP native client needs a recognized DNS provider plugin name
  passed through `spec.dnsProvider` on the device or per cert.
- If your DNS provider isn't on the native client's supported list, the
  fallback is **`acme-dns` CNAME delegation**: stand up a small
  `acme-dns` server (or use a hosted one), and create one CNAME per
  host in your real DNS pointing the `_acme-challenge` record at a
  delegated zone the BIG-IP *can* update. The BIG-IP only ever talks
  to the `acme-dns` server; your real DNS only contains static CNAMEs.

## HTTP-01 specifics

- Requires a listener on :80 reachable from the gateway. Configure a
  small virtual server on the BIG-IP that responds to
  `/.well-known/acme-challenge/*` (the native client provisions this
  automatically when given a `listenerVS`).
- If your security posture doesn't allow :80 on the BIG-IP, use one of
  the other two.

## TLS-ALPN-01 specifics

- Uses :443 only. The BIG-IP must terminate TLS for the validated host.
- Cannot be used behind another TLS-terminating device that doesn't
  forward the `acme-tls/1` ALPN protocol.
- Same wildcard restriction as HTTP-01.

## Wildcard certificates

ACME spec requires DNS-01 for any identifier starting with `*.`. The
schema (`schema/managedcertificate.schema.json`) enforces this at
validation time — a wildcard SAN with `challenge: http-01` or
`tls-alpn-01` will be rejected by `f5acmectl validate`.
