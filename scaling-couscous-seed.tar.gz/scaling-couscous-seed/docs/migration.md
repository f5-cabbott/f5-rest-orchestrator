# Migration: legacy `f5-rest-orchestrator` → this project

The legacy
[`f5-cabbott/f5-rest-orchestrator`](https://github.com/f5-cabbott/f5-rest-orchestrator)
is a Keyfactor Universal Orchestrator extension written in .NET. It
manages BIG-IP certificate stores via the iControl REST API, including
`/mgmt/tm/util/bash` calls. Known issues drove the move to the design
in this repository:

- Shell-injection vectors in BASH-utility paths.
- Global TLS validation bypass during file uploads.
- Sync-over-async HTTP calls (`.Result`) and per-request `HttpClient`
  instantiation.
- Targets `net6.0` (out of support since November 2024).
- No automated test coverage and no security CI.

The retirement plan is **per-partition parallel-run, then decommission**.
No big-bang cutovers.

## Phase-by-phase

### 1. Inventory

- Enumerate every cert managed by the legacy orchestrator. Existing
  inventory jobs already produce this data; export it.
- For each cert, capture: BIG-IP host, partition, store-type
  (`F5-CA-REST` / `F5-SL-REST` / `F5-WS-REST`), cert alias, expiry,
  CA, current key type.
- Cross-reference with BIG-IP version. Anything below TMOS 17.5 either
  upgrades or is excluded from automation.

### 2. Author manifests

For each in-scope cert:

- Choose challenge type per [docs/challenges.md](challenges.md).
- Create the `BigIPDevice` and `ManagedCertificate` manifests under
  `environments/<env>/`.
- Confirm the gateway policy template exists for the target CA and
  cert profile.

Start in `environments/lab`, validate, then promote to `stage`, then
`prod`.

### 3. Parallel run

- Leave the legacy orchestrator extension installed and registered.
- Configure the BIG-IP native ACME client to enroll under the new
  flow. The cert lives at a different filestore name from the legacy
  one — no collision.
- Wait one full renewal cycle (typically 60–90 days depending on
  validity) where:
  - The new path issues and renews the cert successfully.
  - The reconciler reports zero drift.
  - The legacy orchestrator's inventory job still sees its own cert
    object (untouched).

### 4. Cutover (per partition)

After the parallel run completes successfully for every cert in a
partition:

1. Update the SSL profile bindings to point at the new ACME-issued
   cert. (`f5acmectl apply` does this when the manifest's `bindings`
   list is in place.)
2. Verify VIPs serve the new cert chain (`openssl s_client` from a
   reachable host; check expected SAN/Issuer).
3. In Keyfactor: deregister the legacy store-type entries for that
   partition's certs. Do not uninstall the orchestrator extension yet
   — other partitions still need it.
4. Wait one observation window (default 7 days) before cleaning up the
   old cert/key objects in the BIG-IP filestore via
   `f5acmectl apply` (it handles `retainOldCertDays`).

### 5. Decommission

Once every partition is cut over:

1. Uninstall the orchestrator extension from Keyfactor.
2. Archive the `f5-rest-orchestrator` repo (read-only, with a badge in
   its README pointing here).
3. Tighten the BIG-IP service account's iControl REST permissions —
   remove any rights that were only needed for the BASH-utility paths
   in the legacy code.
4. Update internal documentation and runbooks to point at this repo.

## Rollback

At any point before decommission, rollback is:

1. Re-bind SSL profiles to the legacy cert objects (still on the
   BIG-IP for `retainOldCertDays`).
2. Remove the affected `ManagedCertificate` manifests from
   `environments/<env>/certs/`, run `f5acmectl plan` and `apply` to
   tear down ACME accounts and EABs for those certs.
3. The legacy orchestrator extension picks up renewals on its
   original schedule.

After decommission, rollback is no longer in scope — the legacy
extension is gone.

## Risks specific to migration

| Risk | Mitigation |
|---|---|
| Both paths try to manage the same SSL profile binding | Manifest validation requires explicit `bindings`; legacy paths are not touched until step 4 of cutover. |
| Old cert garbage-collected before VIPs are confirmed serving the new one | `retainOldCertDays` defaults to 7; verify before reducing. |
| Renewal happens during cutover window | Stagger cutovers away from known renewal windows; reconciler alerts if a renewal is overdue. |
| Operators need both runbooks during parallel run | Keep legacy runbook in `f5-rest-orchestrator/Troubleshooting.md` until full decommission; this repo's runbook covers the new path only. |
