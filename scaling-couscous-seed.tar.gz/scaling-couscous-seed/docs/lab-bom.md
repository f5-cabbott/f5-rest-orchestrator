# Lab Bill of Materials

Self-contained lab to prove the full path: `f5acmectl` → manifests →
gateway ACME plugin → CA → BIG-IP native ACME client → SSL profile →
VIP. Sized to deliver Phases 2–4 of the project plan.

> All cost figures are *order-of-magnitude* for budget conversations,
> not vendor quotes. Items marked **(quote)** must come from the
> respective vendor.

## 1. Compute & infrastructure

| Item | Sizing | Source | Est. annual cost | Notes |
|---|---|---|---|---|
| **BIG-IP VE (primary)** | 4 vCPU / 16 GB / 80 GB / 200 Mbps | F5 VE Lab License or existing ELA | $0 if ELA-covered; else **(quote F5)** | TMOS 17.5+ required. F5 offers 90-day eval VE licenses. |
| **BIG-IP VE (HA secondary)** | same | same | same | Optional in Phase 2; required to validate HA before prod. Defer if budget-constrained. |
| **Hypervisor / cloud capacity** | ~12 vCPU / 48 GB / 500 GB total | Existing on-prem or AWS/Azure/GCP | $200–500/mo if cloud | Hosts gateway, BIG-IPs, supporting services. |
| **Lab network segment** | /24, isolated, with controlled egress | Existing | $0 | Needs DNS resolution; outbound 443 to gateway. |
| **Internal lab DNS zone** | e.g. `lab.f5acme.example.com` | Existing internal DNS or BIND VM | $0 | Hosts the names used in HTTP-01 / TLS-ALPN-01 / DNS-01 testing. |

## 2. Keyfactor stack

| Item | Sizing | Source | Est. cost | Notes |
|---|---|---|---|---|
| **AnyCA Gateway REST 24.2+** | 1 instance, 4 vCPU / 8 GB / 50 GB | Keyfactor licensing | **(quote)** | Lab/non-prod license tier. |
| **ACME plugin** | n/a | Keyfactor licensing | **(quote)** | Required. Confirm entitlement explicitly. |
| **CA connector** | n/a | Keyfactor licensing | **(quote)** | One per backend CA used in lab. |
| **CA backend (lab)** | EJBCA Community VM **or** existing dev ADCS | OSS / existing | $0 | Don't use prod CA for lab. |
| **Keyfactor Command (optional in lab)** | — | Keyfactor licensing | **(quote)** | Only needed if validating inventory sync. Defer if license-constrained. |

## 3. Secret backend

| Item | Sizing | Source | Est. cost | Notes |
|---|---|---|---|---|
| **HashiCorp Vault (lab)** | Single node, dev or OSS | OSS | $0 | Reference backend. |
| **AWS Secrets Manager / Azure Key Vault** | per-secret pricing | Cloud | < $5/mo for lab volume | Pick whichever matches your prod direction. |

## 4. Tooling & CI

| Item | Sizing | Source | Est. cost | Notes |
|---|---|---|---|---|
| **`f5acmectl`** | n/a | This project (Go) | $0 | The deliverable. |
| **CI runner** | 2 vCPU / 4 GB | GitHub Actions / GitLab / Jenkins | $0 incremental | Runs `validate` + `plan` on PRs, `apply` on merge. |
| **Container registry** | small | Existing | $0 | For `f5acmectl` container distribution. |
| **State backend** | S3 / GCS / Azure Blob | Cloud | < $1/mo | With object lock + versioning. |
| **Prometheus + Grafana (lab)** | Single-node | OSS / existing | $0 | Reuse prod observability if available. |
| **`acme-dns` server (contingency)** | tiny VM | OSS | $0 | Stand up only if Phase 2 finds the BIG-IP native client doesn't support your DNS provider. |

## 5. DNS-01 validation target

Pick whichever matches what prod will use:

| Option | Lab cost | Notes |
|---|---|---|
| **Route 53 / Azure DNS / Google Cloud DNS** | $0.50/zone/mo + queries | Easiest if cloud-aligned. |
| **Internal DNS (BIND/Windows DNS) with TSIG** | $0 | Most realistic if prod is internal-DNS-driven. |
| **`acme-dns` CNAME delegation** | $0 | Fallback when neither of the above works. |

## 6. People

| Role | Phases 0–4 | Phases 5–7 |
|---|---|---|
| **Eng lead** (Go-fluent, F5/PKI literate) | 0.6 FTE × 10 weeks | 0.4 FTE × 12 weeks |
| **Platform / network eng** (BIG-IP) | 0.3 FTE × 10 weeks | 0.5 FTE × 12 weeks (during cutover) |
| **PKI / Keyfactor admin** | 0.2 FTE × 10 weeks | 0.2 FTE × 12 weeks |
| **SRE / observability** | 0.1 FTE × 4 weeks (Phase 4) | 0.1 FTE × 4 weeks |
| **Keyfactor PS / SE** | engagement during Phase 2 | on-call during Phase 5 cutover |

## 7. One-time vs recurring

| | One-time | Recurring (annual) |
|---|---|---|
| **Vendor licensing** | gateway+plugin install/config | gateway+plugin maintenance, F5 ELA delta |
| **Cloud compute (if used)** | — | $2–6k for lab capacity |
| **People** | bulk in Phases 0–4 | reconciler/runbook ownership ~0.1 FTE steady state |
| **Decommission credit** | — | Eliminate maintenance burden of `f5-rest-orchestrator` |

## 8. Trim points (priority order to cut)

1. Drop the second BIG-IP VE in lab; do HA validation in stage.
2. Defer Keyfactor Command in lab (gateway alone proves ACME).
3. Use existing dev ADCS instead of standing up EJBCA.
4. Reuse prod observability stack instead of standing up lab
   Prometheus/Grafana.

What you should **not** trim: the ACME plugin license (no plugin = no
project), or engineering time for `f5acmectl` v0.1.

## 9. What to put in front of finance

> **Lab phase, one-time:**
> - Keyfactor AnyCA Gateway REST 24.2 license + ACME plugin + CA
>   connector — **(quote)**
> - Compute (cloud or on-prem) for ~6 lab VMs — ~**$3–6k/yr** if cloud,
>   $0 if on-prem
> - Engineering time, ~10 weeks, ~1.2 FTE blended — **$X** at your
>   loaded rate
>
> **Steady state, recurring:**
> - Gateway + plugin maintenance — **(quote)**
> - Reconciler ops — ~0.1 FTE
>
> **Offsetting savings:**
> - Retirement of `f5-rest-orchestrator` (security debt: command
>   injection, EoL frameworks, no test coverage).
> - Elimination of orchestrator-extension upgrade treadmill on every
>   Keyfactor UO release.
> - Reduction in cert-related incidents (renewals are the BIG-IP's
>   job, not a job-poll loop).
