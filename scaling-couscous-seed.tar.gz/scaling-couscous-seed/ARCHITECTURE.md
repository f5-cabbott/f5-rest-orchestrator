# Architecture

**Project:** keyfactor-big-ip-cert-broker
**Status:** Draft v1
**Replaces:** `f5-cabbott/f5-rest-orchestrator` (Keyfactor Universal
Orchestrator extension, .NET)

---

## 1. Executive summary

Replace the legacy Keyfactor Universal Orchestrator F5 extension with a
native ACMEv2 integration. BIG-IP 17.5+ acts as its own ACME client,
sourcing certificates from a Keyfactor AnyCA Gateway REST 24.2+ instance
running the ACME plugin. A small Go-based provisioning tool (`f5acmectl`)
declaratively manages EAB credentials, BIG-IP ACME configuration, and
cert-to-profile bindings from version-controlled manifests. The existing
.NET orchestrator extension is retired.

## 2. Goals & non-goals

**Goals**

- Eliminate the .NET orchestrator extension and its operational debt
  (command-injection risk, sync-over-async, global TLS bypass, EoL
  frameworks).
- Native, push-free certificate lifecycle on BIG-IP: enrollment, renewal,
  rebind, revoke.
- Declarative configuration in Git, applied via CI.
- Per-partition tenancy preserved; multi-CA backends preserved via
  gateway connectors.
- Drift detection and pre-expiry alerting independent of the issuance
  path.

**Non-goals (this phase)**

- NGINX / NGINX Plus cert automation — Phase 2.
- BIG-IP versions earlier than 17.5 — out of scope; upgrade or excluded
  from automation.
- Replacing Keyfactor Command itself or any CA upstream of the gateway.
- CA bundle (trust store) management — separately scoped follow-up; ACME
  doesn't address it.

## 3. Architecture

```
                         (Git repo: manifests + schema)
                                    │
                                    ▼
                          CI runs `f5acmectl plan`
                          on PR; `apply` on merge
                                    │
                ┌───────────────────┼─────────────────────┐
                ▼                   ▼                     ▼
        Secret backend     Keyfactor AnyCA            BIG-IP fleet
        (Vault/AWS-SM/      Gateway REST 24.2+      (TMOS 17.5+, native
         Azure-KV)          + ACME plugin             ACMEv2 client)
                │           + CA connectors                │
        EAB material       (ADCS/EJBCA/etc.)           │  │
        ACME account keys           ▲                  │  │
                                    │ ACMEv2 over HTTPS │ │
                                    └───────────────────┘ │
                                                          │ HTTP-01 / DNS-01 / TLS-ALPN-01
                                                          ▼
                                                    Cert installed on
                                                    SSL profiles → VIPs
```

`f5acmectl` only runs at change time and on a reconcile schedule.
Steady-state issuance and renewal happen entirely between BIG-IP and the
gateway with no intermediary.

## 4. Functional requirements

### Issuance & renewal

- **FR-1** Each managed certificate is enrolled by the BIG-IP's native
  ACMEv2 client against the gateway's ACME directory.
- **FR-2** Renewal is automatic, driven by the BIG-IP at
  `notAfter − renewBeforeDays` (configurable per cert; default 30).
- **FR-3** All three challenge types are supported and selectable per
  cert: **HTTP-01**, **DNS-01**, **TLS-ALPN-01**. See
  [docs/challenges.md](docs/challenges.md).
- **FR-4** Wildcard certs are supported via DNS-01 only (ACME spec
  constraint).
- **FR-5** Issued certs are bound to one or more `client-ssl` profiles
  named in the manifest; binding is atomic via iControl REST transactions.
- **FR-6** Old cert/key objects retained for N days post-rotation
  (default 7), then garbage-collected.

### EAB & account management

- **FR-7** EAB credentials are minted via the gateway admin API, never
  via the UI, and stored in the configured secret backend.
- **FR-8** EAB scope is configurable: per-device, per-partition,
  per-environment. Default: **per-partition**. See
  [docs/eab.md](docs/eab.md).
- **FR-9** EAB rotation is supported on demand and on a configurable
  schedule (default 365 days). Old EABs are revoked after the new ACME
  account is confirmed working.
- **FR-10** Each `kid` is mapped at the gateway to a Keyfactor cert
  template / CA / SAN allow-list; mappings are codified, not click-ops.

### Configuration model

- **FR-11** Three manifest kinds (YAML, JSON-Schema validated):
  - `GatewayConfig` — one per environment; gateway URL, defaults, EAB
    policy.
  - `BigIPDevice` — one per appliance/cluster; host, partitions,
    credentials reference, challenge responder config.
  - `ManagedCertificate` — one per cert; identifiers, key type,
    challenge type, profile bindings, policy template.
- **FR-12** Per-cert overrides for key type, challenge type, renewal
  window, contact email.
- **FR-13** Secret references use `secret://<backend>/<path>` URIs;
  literal secrets in manifests are rejected by validation.

### Tooling (`f5acmectl`)

- **FR-14** Subcommands: `validate`, `discover`, `plan`, `apply`,
  `verify`, `state`, `reconcile`, `revoke`, `rotate-eab`.
- **FR-15** `plan` emits a human-readable diff and a machine-readable
  plan file consumable by `apply`.
- **FR-16** `apply` is idempotent, requires explicit confirmation or a
  prior plan file, and acquires a state-backend lock for the duration.
- **FR-17** `reconcile` is read-only; runs on a schedule and emits
  drift / near-expiry / orphan-EAB alerts.
- **FR-18** All mutations are audit-logged with actor, git SHA of the
  manifest set, target, and gateway request-id.
- **FR-19** Pre-flight checks fail fast on: BIG-IP TMOS < 17.5, missing
  ACME directory, unreachable gateway, unresolvable secrets,
  schema-invalid manifests.

### Drift & expiry monitoring

- **FR-20** Reconciler diffs each BIG-IP's installed certs against
  Keyfactor inventory and against the desired-state manifests; alerts on
  three classes: *orphan on device*, *missing on device*, *config drift*.
- **FR-21** Alerts on any cert with `notAfter` ≤ 14 days and no
  successful renewal in the last 24 hours.
- **FR-22** Metrics exposed in Prometheus format:
  `f5acme_orders_total`, `f5acme_renewal_failures_total`,
  `f5acme_cert_expiry_seconds`, `f5acme_reconcile_drift_total`.

## 5. Non-functional requirements

| Area | Requirement |
|---|---|
| **Security** | No secrets in manifests, state, or logs. Gateway communication mTLS where supported. BIG-IP API account uses a least-privilege role (Certificate Manager equivalent), no admin. EAB material write-once to vault, read-on-demand. |
| **Availability** | Gateway deployed HA per Keyfactor recommendation. Reconciler runs hourly; issuance/renewal does not depend on `f5acmectl` being available. |
| **Performance** | Tool handles a fleet of `<N>` devices and `<M>` certs with `plan` ≤ 60 s and `apply` ≤ 5 min for a typical change set (single cert). |
| **Auditability** | Every change traceable to a Git commit, an `f5acmectl` invocation, and a gateway request-id. Retention ≥ 1 year. |
| **Operability** | Single static binary. Runs in CI runners, on a bastion, or in a Kubernetes CronJob without code changes. |
| **Recoverability** | State backend versioned + locked. Manifest repo is the source of truth; full rebuild possible from `git clone` + `f5acmectl apply`. |

## 6. Configuration model

Three `kind`s, JSON-Schema validated, secret refs only. Schemas live in
[`schema/`](schema/). Worked examples in [`examples/`](examples/).

## 7. Tooling: `f5acmectl`

- **Language:** Go (CNCF alignment, single-binary distribution).
- **Distribution:** signed release artifacts on internal artifact store;
  container image for CI use.
- **State backend:** S3 / GCS / Azure Blob with object lock
  (Terraform-style).
- **Secret backends (pluggable):** Vault first, AWS Secrets Manager and
  Azure Key Vault to follow.
- **Test strategy:** unit tests on plan/diff logic; integration tests
  against a lab BIG-IP + lab gateway in CI; contract tests against
  recorded gateway/iControl REST fixtures.

## 8. Operational model

- **GitOps:** manifests in Git. PRs run `validate` + `plan`. Merge to
  `main` triggers `apply` from a pipeline with read access to the secret
  backend and write access to gateway + BIG-IPs.
- **Change control:** `plan` output is the artifact reviewers approve.
  `apply` requires either a prior plan file or `--yes` (the latter
  restricted to the pipeline service account).
- **Secrets:** Vault is the reference backend. EAB material and BIG-IP
  API creds never appear in manifests, state, logs, or CI variables —
  only secret URIs do.
- **Observability:** Prometheus scrape on the reconciler; structured JSON
  logs shipped to the existing log aggregation; PagerDuty (or
  equivalent) for the expiry/drift/renewal-failure alerts.
- **On-call runbook:** see [docs/runbook.md](docs/runbook.md).

## 9. Migration plan

See [docs/migration.md](docs/migration.md).

## 10. Phased plan & milestones

| Phase | Work | Duration | Gate |
|---|---|---|---|
| **0. Prereqs** | Keyfactor licensing for AnyCA Gateway REST 24.2 + ACME plugin; entitlement check; lab BIG-IP at 17.5+; secret backend available | 4–8 weeks elapsed (mostly procurement) | License + lab hardware |
| **1. Inventory & gap analysis** | BIG-IP version audit; cert catalog; DNS-01 provider feasibility; partition/EAB scoping decision | 1 week | Signed-off cert catalog |
| **2. Lab build** | Stand up gateway 24.2 + ACME plugin in lab; first cert end-to-end via native client; validate all three challenge types; confirm DNS-01 provider support | 2–3 weeks | One renewal observed in lab |
| **3. `f5acmectl` v0.1** | Schema + validate/plan/apply/verify; single-environment scope | 3–4 weeks | Lab cert managed end-to-end via tool |
| **4. Reconciler + observability** | `reconcile` subcommand, metrics, alerts, runbook | 2 weeks | Drift/expiry alerts firing in lab |
| **5. Stage rollout** | Manifests for stage; parallel-run with legacy; one renewal cycle | 2–4 weeks | Zero drift over a renewal cycle |
| **6. Prod rollout** | Per-partition migration; decommission legacy per partition | 4–8 weeks | All partitions migrated |
| **7. Decommission** | Archive `f5-rest-orchestrator`; remove orchestrator extension; tighten service-account perms | 1 week | Legacy code path gone |

Phase 2 (NGINX) starts after Phase 7.

## 11. Risks & dependencies

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Keyfactor licensing delay | High | Blocks Phase 2+ | Submit licensing ask immediately; track as critical path |
| BIG-IP 17.5 native ACME client lacks our DNS provider | Medium | Forces sidecar (lego) or `acme-dns` delegation | Verify in lab Phase 2; `acme-dns` documented as fallback |
| Gateway 24.2 upgrade affects other Keyfactor consumers | Medium | Cross-team coordination required | Stakeholder map in Phase 0; lab-rehearse the upgrade |
| BIG-IP fleet has appliances < 17.5 | Variable | Scope reduction or upgrade ticket | Inventory in Phase 1; document excluded devices |
| EAB credential compromise | Low | Rogue cert issuance under that scope | Per-partition scoping limits blast radius; rotation supported; revocation procedure in runbook |
| ACME plugin behaves differently than spec at edges | Medium | Integration bugs | Conformance test suite against the gateway in CI |

## 12. Open questions

1. EAB scope final decision — per-partition (default recommendation) or
   per-device?
2. Secret backend — confirm Vault is the chosen one, or is it
   AWS SM / Azure KV?
3. Which DNS provider(s) need DNS-01 support, and are they in the
   BIG-IP 17.5 native client's provider list?
4. CI platform for the GitOps pipeline (GitHub Actions / GitLab CI /
   Jenkins)?
5. Where does the reconciler run (CI cron, k8s CronJob, systemd timer
   on a bastion)?
6. CA bundle / trust store automation — separate project or appended
   here later?
7. Cert revocation policy — automatic on decommission, or always manual?
