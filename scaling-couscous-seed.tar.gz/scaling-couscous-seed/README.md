# keyfactor-big-ip-cert-broker

Declarative, GitOps-driven certificate lifecycle for **F5 BIG-IP** sourcing
certificates from a **Keyfactor AnyCA Gateway REST 24.2+** instance running
the ACME plugin.

> **Status:** Pre-alpha. Skeleton + design artifacts. No working binary yet.
> See [ARCHITECTURE.md](ARCHITECTURE.md) for the full design and
> [docs/migration.md](docs/migration.md) for the cutover plan from the
> legacy `f5-rest-orchestrator` Keyfactor Universal Orchestrator extension
> this project replaces.

## What this is

- **A declarative configuration model** (YAML manifests, JSON-Schema
  validated) describing which BIG-IP devices and certificates participate
  in ACME-driven cert lifecycle, and how.
- **`f5acmectl`** — a single-binary Go tool that reconciles those
  manifests against the gateway's admin API and the BIG-IP's iControl
  REST surface. It mints EAB credentials, configures the BIG-IP's
  **native ACMEv2 client** (TMOS 17.5+), binds issued certs to client/
  serverSSL profiles, and watches for drift.
- **Operational documentation** — runbook, lab BOM, EAB explainer,
  challenge-type selection, migration plan.

## What this is not

- **An ACME client.** The BIG-IP itself is the ACME client. `f5acmectl`
  is a provisioning + reconciliation tool; it never holds account keys
  or HMAC material at runtime beyond the moment of EAB minting.
- **A Keyfactor Universal Orchestrator extension.** The legacy `.NET`
  extension being retired by this project lives at
  [`f5-cabbott/f5-rest-orchestrator`](https://github.com/f5-cabbott/f5-rest-orchestrator).
- **A drop-in replacement for any other ACME tool.** Lego, certbot,
  cert-manager, etc. have different problem shapes — this is purpose-built
  for the Keyfactor-AnyCA-Gateway → BIG-IP path.

## Hard prerequisites

| Thing | Minimum |
|---|---|
| **F5 BIG-IP TMOS** | 17.5.0 (native ACMEv2 client) |
| **Keyfactor AnyCA Gateway REST** | 24.2 |
| **Keyfactor ACME plugin** | licensed and loaded on the gateway |
| **Secret backend** | HashiCorp Vault, AWS Secrets Manager, or Azure Key Vault |
| **State backend** | S3, GCS, Azure Blob, or local file (lab only) |

## Repo layout

```
.
├── cmd/f5acmectl/        # CLI entry point
├── internal/             # tool internals (not importable by other modules)
│   ├── cmd/              # cobra command tree
│   ├── manifest/         # GatewayConfig / BigIPDevice / ManagedCertificate types + Loader
│   ├── gateway/          # Keyfactor AnyCA Gateway admin-API client
│   ├── bigip/            # F5 iControl REST client (TMOS 17.5+ native ACME)
│   ├── secrets/          # pluggable Vault / AWS SM / Azure KV backend
│   └── state/            # locked, versioned snapshot backend
├── schema/               # JSON Schemas (Draft 2020-12) — source of truth for manifests
├── examples/             # worked example manifests
├── docs/
│   ├── eab.md            # External Account Binding explainer
│   ├── challenges.md     # http-01 / dns-01 / tls-alpn-01 selection guide
│   ├── migration.md      # cutover from legacy .NET orchestrator extension
│   ├── runbook.md        # on-call procedures
│   └── lab-bom.md        # bill of materials for the lab build
├── ARCHITECTURE.md       # full design doc
├── SECURITY.md           # disclosure policy
├── CHANGELOG.md
├── LICENSE               # Apache-2.0
├── NOTICE
└── go.mod
```

## Quickstart (lab)

> Not functional yet. Steps documented for the design target.

```sh
# 1. Build
go build -o bin/f5acmectl ./cmd/f5acmectl

# 2. Validate your manifests against the schemas
./bin/f5acmectl validate -m ./environments/lab

# 3. See what will change
./bin/f5acmectl plan -m ./environments/lab --out plan.json

# 4. Apply (requires state backend + secret backend reachable)
./bin/f5acmectl apply --plan-file plan.json

# 5. Verify post-apply
./bin/f5acmectl verify -m ./environments/lab

# 6. Schedule the reconciler (cron / k8s CronJob / systemd timer)
./bin/f5acmectl reconcile -m ./environments/lab --metrics-addr :9090
```

## Project status & roadmap

See [ARCHITECTURE.md](ARCHITECTURE.md) §10 for the phased plan. Current
gates:

- [ ] **Phase 0** — Keyfactor licensing (AnyCA Gateway REST 24.2 + ACME plugin)
- [ ] **Phase 1** — Inventory & gap analysis
- [ ] **Phase 2** — Lab build (gateway + 1 BIG-IP, end-to-end issuance)
- [ ] **Phase 3** — `f5acmectl` v0.1 (validate / plan / apply / verify)
- [ ] **Phase 4** — Reconciler + observability
- [ ] **Phase 5** — Stage rollout
- [ ] **Phase 6** — Production rollout (per-partition)
- [ ] **Phase 7** — Decommission legacy orchestrator extension

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) (TBD) and [SECURITY.md](SECURITY.md)
for vulnerability disclosure.

## License

Apache License 2.0. See [LICENSE](LICENSE) and [NOTICE](NOTICE).
