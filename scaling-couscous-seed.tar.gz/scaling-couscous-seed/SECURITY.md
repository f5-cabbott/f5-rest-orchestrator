# Security policy

## Reporting a vulnerability

**Do not file a public issue.** Report suspected vulnerabilities by
opening a private security advisory on GitHub:

> Repository → Security → Report a vulnerability

Include:

- Affected version (`f5acmectl version` output, or commit SHA).
- Reproduction steps or proof-of-concept.
- Impact assessment (what an attacker can read, modify, or execute).
- Any mitigations already in place.

Acknowledgement target: 3 business days. Triage target: 10 business
days. Coordinated disclosure window: typically 90 days from triage,
shorter when active exploitation is observed.

## Scope

In scope:

- The `f5acmectl` binary and its Go modules under `cmd/` and `internal/`.
- The JSON Schemas under `schema/`.
- CI workflows under `.github/workflows/`.

Out of scope (report upstream):

- BIG-IP TMOS itself (F5 PSIRT).
- Keyfactor AnyCA Gateway / ACME plugin (Keyfactor support).
- ACME protocol RFCs.
- Third-party Go modules (report to the module's maintainer; we will
  pin/fork as needed).

## Threat model summary

`f5acmectl` is an *administrative* tool — it holds high-privilege
credentials at apply time (gateway admin, BIG-IP API, secret-backend
access) and writes to a state store. The threat model assumes:

- The host running `f5acmectl` is at least as trusted as the BIG-IPs and
  gateway it manages.
- The secret backend is the source of truth for credentials; manifests
  and state must never carry secret values.
- The state backend is integrity-protected and access-controlled.
- The CI runner that invokes `apply` is hardened (ephemeral, OIDC-based
  cloud auth, no long-lived static credentials).

## Known sensitive surfaces

Documented for reviewer awareness; each has a mitigation in the design:

| Surface | Risk | Mitigation |
|---|---|---|
| EAB HMAC key in transit (CreateEAB → secret backend) | Disclosure → rogue ACME account creation | Never logged; written to backend within the same process; backend access audit-logged. |
| BIG-IP API credentials | Disclosure → device compromise | Stored in secret backend; least-privilege role; never written to state. |
| State snapshot integrity | Tampering → false reconciliation | Backend versioning + object lock; signed snapshots planned for v1. |
| Manifest repository | Tampering → unauthorized issuance | Branch protection + required reviews + signed commits + CI gate on `validate` and `plan`. |
| Logs | Credential leakage | Authorization headers and HMAC keys are redacted at the sink; trace-level logs disabled in production. |

## Supported versions

Pre-1.0 — no LTS. Once 1.0 ships, security fixes are backported to the
two most recent minor versions; older versions receive only critical
fixes for 90 days post-release.
