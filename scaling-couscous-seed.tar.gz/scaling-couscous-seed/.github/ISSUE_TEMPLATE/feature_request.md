---
name: Feature request
about: Suggest a new capability or enhancement
title: ""
labels: enhancement
assignees: ""
---

## Problem

<!-- What problem are you trying to solve? Who is affected? -->

## Proposed solution

<!-- What should the tool / schema do? Sketch a manifest snippet or CLI invocation. -->

## Alternatives considered

<!-- Why not just do X with the existing tool? What did you try? -->

## Out of scope

<!-- Things this proposal explicitly does NOT cover. -->

## Additional context

<!-- Constraints, deadlines, related issues, links to upstream features, etc. -->
