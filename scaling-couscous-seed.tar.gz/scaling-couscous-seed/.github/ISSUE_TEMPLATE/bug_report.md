---
name: Bug report
about: Something is broken or behaves unexpectedly
title: ""
labels: bug
assignees: ""
---

## What happened

<!-- Concise description of the actual behavior. -->

## What you expected

<!-- Concise description of expected behavior. -->

## How to reproduce

1.
2.
3.

## Environment

- `f5acmectl version`:
- BIG-IP TMOS version:
- Keyfactor AnyCA Gateway version + ACME plugin version:
- Secret backend (vault / aws-sm / azure-kv):
- State backend (s3 / gcs / azure-blob / file):
- OS (where `f5acmectl` runs):

## Logs / output

<!-- Paste relevant logs. **Redact secrets and host identifiers** before posting. -->

```
```

## Manifest excerpt (redacted)

```yaml
```

## Additional context

<!-- Anything else? Recent changes? Workarounds tried? -->
