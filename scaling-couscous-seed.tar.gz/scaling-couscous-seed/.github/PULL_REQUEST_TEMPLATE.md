<!-- Thanks for the PR. Please fill out the sections below. -->

## What

<!-- One or two sentences. What does this PR change? -->

## Why

<!-- Link the issue, design discussion, or runbook. -->
Closes #

## How to verify

<!-- Reviewer should be able to follow these to confirm correctness. -->
- [ ]
- [ ]

## Risk & blast radius

<!-- Tick what applies. -->
- [ ] No runtime behavior change (docs / CI / refactor only)
- [ ] Manifest schema change (requires existing manifests to be re-validated)
- [ ] Touches a security-sensitive package (`internal/secrets`, `internal/state`, `internal/gateway`, `internal/bigip`)
- [ ] Changes default behavior of a subcommand
- [ ] Adds a new external dependency

## Pre-merge checklist

- [ ] `go build ./...` succeeds
- [ ] `go test ./... -race` passes
- [ ] `golangci-lint run` clean
- [ ] Schema changes (if any) validated against examples in `examples/`
- [ ] Updated `CHANGELOG.md`
- [ ] Updated docs in `docs/` if user-visible behavior changed
