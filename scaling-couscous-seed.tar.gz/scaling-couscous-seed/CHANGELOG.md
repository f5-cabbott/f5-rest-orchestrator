# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)
once it ships 1.0.

## [Unreleased]

### Added

- Initial repository scaffolding.
- JSON Schemas for `GatewayConfig`, `BigIPDevice`, `ManagedCertificate`.
- Worked example manifests.
- `f5acmectl` Go skeleton (cobra command tree; subcommands stubbed).
- Manifest types and `Loader` interface.
- Pluggable interfaces for the Keyfactor AnyCA Gateway admin API,
  F5 iControl REST client, secret backends (Vault / AWS SM / Azure KV),
  and the locked, versioned state snapshot store.
- Apache 2.0 license, NOTICE file, and per-source-file license headers.
- Project documentation: README, ARCHITECTURE, SECURITY, runbook,
  EAB explainer, challenge-type guide, migration plan, lab BOM.
- CI workflows: build/test/lint, CodeQL, JSON Schema validation,
  Dependabot.

### Changed

_nothing yet_

### Deprecated

_nothing yet_

### Removed

_nothing yet_

### Fixed

_nothing yet_

### Security

- Replaces the legacy `f5-rest-orchestrator` Keyfactor Universal
  Orchestrator extension; that codebase carries known security findings
  (command injection in BASH-utility iControl calls, global TLS
  validation bypass, sync-over-async, EoL frameworks). This project's
  design eliminates those classes by removing the affected code paths
  entirely.
